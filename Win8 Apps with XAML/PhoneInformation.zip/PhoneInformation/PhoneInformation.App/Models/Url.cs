﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PhoneInformation.App.Models
{
    public  class Parameters
    {
        public static string location;
        public static string brand;
        public static string firstPhoneId;
        public static string secondPhoneId;
        public Parameters()
        {
            
        }

    }
}
